import UIKit

//Conditionals
//if, switch, ternary (if and action 1 line)
//If statement example by me
let valueCoba = 80
if valueCoba < 100 {
    print("That's what I want!")
} else {
    print("Too high!")
}
//Boolean result
let isValueNumber = valueCoba < 100
print(isValueNumber)

var isSnowing = false
if !isSnowing {
    print("I can go everywhere")
}

//When there's a lot of if else if, use switch

var age = 29
age = 30
print(age)


